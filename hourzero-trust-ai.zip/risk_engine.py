def calculate_risk(score):
    if score > 80:
        return "High Risk"
    elif score > 50:
        return "Medium Risk"
    else:
        return "Low Risk"
